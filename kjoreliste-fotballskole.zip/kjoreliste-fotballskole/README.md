# Kjøreliste fotballskole uke 26

En enkel statisk nettside for kjøreliste fra Gjellum til fotballskolen på Arnestad.

## Publiser på GitHub Pages

1. Lag et nytt repository på GitHub, for eksempel `kjoreliste-fotballskole`.
2. Last opp `index.html` til repositoryet.
3. Gå til **Settings → Pages**.
4. Velg **Deploy from a branch**.
5. Velg branch `main` og mappe `/root`, og trykk **Save**.
6. GitHub gir deg en URL når siden er publisert.

Startdato i koden er satt til mandag 22. juni 2026.
